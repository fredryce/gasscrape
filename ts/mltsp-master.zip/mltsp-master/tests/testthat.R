library("mltsp")
library("testthat")

test_check("mltsp")
